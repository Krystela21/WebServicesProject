package universite.management.client.Client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

public class RestClient {

	/* This is the link of the service resource */
	private static final String REST_URI = "http://localhost:8080/universite.management.web/api/universites";
 
	private Client client = ClientBuilder.newClient();

	public Universite getUniversite(int id) {
		return client.target(REST_URI).path(String.valueOf(id)).request(MediaType.APPLICATION_XML).get(Universite.class);
	}
   
	public String getAllUniversites() {
		return client.target(REST_URI).request(MediaType.APPLICATION_XML).get().toString();//post(Entity.entity(MediaType.APPLICATION_XML));
	}
	
	public Response createXMLUniversite(Universite stud) {
	    return client.target(REST_URI).request(MediaType.APPLICATION_XML).post(Entity.entity(stud, MediaType.APPLICATION_XML));
	}
}
