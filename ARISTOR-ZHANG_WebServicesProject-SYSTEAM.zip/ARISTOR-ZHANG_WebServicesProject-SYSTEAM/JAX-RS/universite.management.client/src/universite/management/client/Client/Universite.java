/**
 * 
 */
package universite.management.client.Client;


import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
/**
 * @author ARISTOR Christella
 *
 */
@XmlRootElement
public class Universite {
	
	private String name;
	private String adress;
	private List<String> specialities = new ArrayList<>();
	private Integer id;

	public Universite() {
		
	}
	
	public Universite(String name, String a, String speciality) {
		this.name = name;
		this.adress = a;
		convertStringToList(speciality);//this.specialities = 
		this.id = null;
	}
	
	public Universite(String name, String a ,String speciality, Integer id) {
		this.name = name;
		this.adress = a;
		this.specialities = convertStringToList(speciality);
		this.id = id;
	}
	
	public List<String> convertStringToList(String input) {
		 List<String> output = new ArrayList<>();
		 if (input != null && !input.isEmpty()) {
			 System.out.println("Les spécialités vont être ajoutées. \n"+input);
		     String[] elements = input.split(",");
		     int i = 0;
		     int max = elements.length;
		     for (i=0;i<max;i++) {
		    	  output.add(elements[i]);
		     }
		 }
		 this.specialities = output;
		 return output;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public List<String> getSpecialities() {
		return specialities;
	}

	public void setSpecialities(List<String> speciality) {
		this.specialities = speciality;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	@Override
	public String toString() {
		return "Universite [id = " + String.valueOf(id) + "name=" + name + ", adress=" + adress + ", speciality=" + specialities.toString() + "] \n";
	}
}

