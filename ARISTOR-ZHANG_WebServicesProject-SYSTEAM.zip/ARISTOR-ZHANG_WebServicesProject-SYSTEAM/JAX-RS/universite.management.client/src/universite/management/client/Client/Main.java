package universite.management.client.Client;

import javax.ws.rs.core.Response;

public class Main {

	public static void main(String[] args) {

		/* Create RestClient object, which serves as the service stub */
		RestClient client = new RestClient();

		/**
		 * Creates new Universite.
		 */
		Universite Universite = new Universite("Universite Paris Saclay","15 rue Georges Clemenceau 91400 Orsay","Droit,Economie,Gestion,Medecine,Pharmacie,Sciences");
		Response response = client.createXMLUniversite(Universite);
		if (response.getStatus() == 200 || response.getStatus() == 201) {
			System.out.println("Universite created:  ");
		}else {
			System.out.println("response status "+response.getStatus());
		}

	/**
	 * Requests all Universites.
	 */
		String Universites =client.getAllUniversites();
		System.out.println(Universites);
		
		/**
		 * Requests one Universite (Universite id=1 given that he/she exists).
		 */
			
			
		System.out.println("universite 1 " + client.getUniversite(1).getName());
				
			
	}

}
