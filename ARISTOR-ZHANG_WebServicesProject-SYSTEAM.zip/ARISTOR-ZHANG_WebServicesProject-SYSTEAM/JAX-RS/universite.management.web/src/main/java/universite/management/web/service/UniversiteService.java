/**
 * 
 */
package universite.management.web.service;
import java.util.*;


import universite.management.web.data.Universite;
/**
 * @author ARISTOR Christella
 *
 */
public class UniversiteService {
	private static Map<Integer, Universite> UNIVERSITE_DATA = new HashMap<Integer, Universite>();
		
		/**
		 * Method to get a new id
		 * 
		 * @param void
		 * @return Integer id
		 */
		private int getNewId() {
			int newId = 0;
			for (int id : UNIVERSITE_DATA.keySet()) {
				if (newId < id)
					newId = id;
			}
			return ++newId;
		}
		
		/**
		 * Method to add an Universite in the HashMap UNIVERSITE_DATA
		 * 
		 * @param Universite u
		 * @return Universite u
		 */
		public Universite addUniversite(Universite s) {
			int id = getNewId();
			if(UNIVERSITE_DATA.get(s.getId()) != null) {
				return null;
			}
			s.setId(id);
			s.convertStringToList(s.getSpecBrut());
			//s.Coordonnees();
			UNIVERSITE_DATA.put(id, s);
			return s;
		}
		
		/**
		 * Method to delete an Universite in the HashMap UNIVERSITE_DATA
		 * 
		 * @param int id
		 * @return boolean
		 */
		public boolean deleteUniversite(int id) {
			 if(UNIVERSITE_DATA.get(id) == null) {
				 return false;
			 }
			 UNIVERSITE_DATA.remove(id);
			 return true;
		}
		
		/**
		 * Method to get an Universite in the HashMap UNIVERSITE_DATA by giving the id
		 * 
		 * @param integer id
		 * @return Universite u
		 */
		public Universite getUniversite(int id) {
			 return UNIVERSITE_DATA.get(id);
		}
		
		/**
		 * Method to get all universities in the HashMap UNIVERSITE_DATA with the same speciality
		 * 
		 * @param String speciality
		 * @return Map<Integer,String> ask
		 */
		public String getUniversiteSpeciality(String speciality) {
			Map<Integer, String> ask = new HashMap<Integer, String>();
			Iterator <Map.Entry<Integer,Universite>> i = UNIVERSITE_DATA.entrySet().iterator(); 
			while (i.hasNext()) {
				Map.Entry<Integer, Universite> tmp = i.next();
				Universite u = tmp.getValue();
				if (u.getSpecialities().contains(speciality)) {
					ask.put(u.getId(), u.getName());
				}
			}
			StringBuilder sb = new StringBuilder();
		    sb.append("<map>");
		    if (UNIVERSITE_DATA != null) {
		    	for (Map.Entry<Integer, String> entry : ask.entrySet()) {
		    		sb.append("<entry>");
		    		sb.append("<key>").append(entry.getKey()).append("</key>");
		    		sb.append("<value>").append(entry.getValue()).append("</value>");
		    		sb.append("</entry>");
		    	}
		    	sb.append("</map>");
		    	return sb.toString();
		    }
		    sb.append("</map>");
	    	return sb.toString();
		}
		
		/**
		 * Method to get all universities in the HashMap UNIVERSITE_DATA
		 * 
		 * @return Map<Integer,String> UNIVERSITE_DATA
		 */
		public String getAllUniversite() {
			StringBuilder sb = new StringBuilder();
		    sb.append("<map>");
		    if (UNIVERSITE_DATA != null) {
		    	for (Map.Entry<Integer, Universite> entry : UNIVERSITE_DATA.entrySet()) {
		    		sb.append("<entry>");
		    		sb.append("<key>").append(entry.getKey()).append("</key>");
		    		sb.append("<value>").append(entry.getValue().toString()).append("</value>");
		    		sb.append("</entry>");
		    	}
		    	sb.append("</map>");
		    	return sb.toString();
		    }
		    sb.append("</map>");
	    	return sb.toString();
		    
		}
		
		/**
		 * Method to update specilaity values
		 * 
		 * @param Integer id
		 * @param String newSpeciality
		 * @return boolean
		 */
		public boolean updateSpeciality(Integer id, String newSpeciality) {
			if(UNIVERSITE_DATA.containsKey(id)) {
				String[] elements = newSpeciality.split(",");
				for (String element : elements) {
					UNIVERSITE_DATA.get(id).getSpecialities().add(element);
				}
				return true;
			}
			return false;
		}
}
