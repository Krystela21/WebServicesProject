package universite.management.web.data;
import com.google.gson.annotations.SerializedName;
import java.util.List;

public class GeoCodeJSON {

    @SerializedName("features")
    private List<Feature> features;

    public List<Feature> getFeatures() {
        return features;
    }

    public static class Feature {

        @SerializedName("geometry")
        private Geometry geometry;

        public Geometry getGeometry() {
            return geometry;
        }

        public static class Geometry {

            @SerializedName("type")
            private String type;

            @SerializedName("coordinates")
            private List<Double> coordinates;

            public String getType() {
                return type;
            }

            public List<Double> getCoordinates() {
                return coordinates;
            }
        }
    }
}