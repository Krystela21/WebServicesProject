/**
 * 
 */
package universite.management.web.data;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;


/**
 * @author ARISTOR Christella
 *
 */
@XmlRootElement
public class Universite {
	
	private String name;
	private String adress;
	private List<String> specialities = new ArrayList<>();
	private String specBrut;
	private Integer id;
	private Double longitude;
	private Double latitude;

	public Universite() {
		
	}
	
	public Universite(String name, String a, String speciality) {
		this.name = name;
		this.adress = a;
		this.specBrut = speciality;
		this.convertStringToList(speciality);
		this.id = null;
	}
	
	public Universite(String name, String a ,String speciality, Integer id) {
		this.name = name;
		this.adress = a;
		this.specBrut = speciality;
		this.specialities = this.convertStringToList(speciality);
		this.id = id;
	}
	
	public void Coordonnees() {
		Coordonnees coor = new Coordonnees(adress);
		setLatitude(coor.latitude());
		setLongitude(coor.latitude());
	}
	
	public List<String> convertStringToList(String input) {
		 List<String> output = new ArrayList<>();
		 if (input != null && !input.isEmpty()) {
			 System.out.println("Les spécialités vont être ajoutées. \n"+input);
		     String[] elements = input.split(",");
		     int i = 0;
		     int max = elements.length;
		     for (i=0;i<max;i++) {
		    	  output.add(elements[i]);
		     }
		 }
		 this.specialities = output;
		 this.setSpecialities(output);
		 return output;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public List<String> getSpecialities() {
		return specialities;
	}

	public void setSpecialities(List<String> speciality) {
		this.specialities = speciality;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getSpecBrut() {
		return specBrut;
	}

	public void setSpecBrut(String specBrut) {
		this.specBrut = specBrut;
	}

	
	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	@Override
	public String toString() {
		return "Universite [name=" + name + ", adress=" + adress + ", specialities=" + specBrut + ", id=" + String.valueOf(id)+"]";
	}
	
	
}


