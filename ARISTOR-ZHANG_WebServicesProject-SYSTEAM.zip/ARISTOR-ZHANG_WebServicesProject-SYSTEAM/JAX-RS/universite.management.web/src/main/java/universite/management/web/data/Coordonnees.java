package universite.management.web.data;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.google.gson.Gson;

//import com.google.gson.Gson;

public class Coordonnees {
	
	private Double lat;
	private Double longi;
	private String add;
	
	
	public Coordonnees(String add) {
		super();
		this.lat = null;
		this.longi = null;
		this.add = add;
	}
	
	public Double latitude() {
		try {
				// Créer une URL pour la requête
			String addPlus = add.replaceAll(" ", "+");
		    URL url = new URL("https://api-adresse.data.gouv.fr/search/?q="+addPlus);
			    // Ouvrir la connexion HTTP
			    HttpURLConnection conn = (HttpURLConnection) url.openConnection();

			    // Définir la méthode de requête (GET)
			    conn.setRequestMethod("GET");

			    // Lire la réponse de la requête
			    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			    String inputLine;
			    StringBuilder response = new StringBuilder();
			    while ((inputLine = in.readLine()) != null) {
			    	response.append(inputLine);
			    }
			    in.close();

			    // Afficher la réponse
			    System.out.println(response.toString());
			    Gson gson = new Gson();
		        GeoCodeJSON geoCodeJSON = gson.fromJson(response.toString(), GeoCodeJSON.class);

		        Double latitude = geoCodeJSON.getFeatures().get(0).getGeometry().getCoordinates().get(1);
		        setLat(latitude);
		        return latitude;
			} catch (Exception e) {
			    System.out.println("Erreur: " + e.getMessage());
			    return (double) 0;
			}
	}
	
	public Double longitude() {
		try {
				// Créer une URL pour la requête
				String addPlus = add.replaceAll(" ", "+");
			    URL url = new URL("https://api-adresse.data.gouv.fr/search/?q="+addPlus);

			    // Ouvrir la connexion HTTP
			    HttpURLConnection conn = (HttpURLConnection) url.openConnection();

			    // Définir la méthode de requête (GET)
			    conn.setRequestMethod("GET");

			    // Lire la réponse de la requête
			    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			    String inputLine;
			    StringBuilder response = new StringBuilder();
			    while ((inputLine = in.readLine()) != null) {
			    	response.append(inputLine);
			    }
			    in.close();

			    // Afficher la réponse
			    System.out.println(response.toString());
			    Gson gson = new Gson();
		        GeoCodeJSON geoCodeJSON = gson.fromJson(response.toString(), GeoCodeJSON.class);
		        Double longitude = geoCodeJSON.getFeatures().get(0).getGeometry().getCoordinates().get(0);
		        setLongi(longitude);
		        return longitude;
			} catch (Exception e) {
			    System.out.println("Erreur: " + e.getMessage());
			    return (double) 0;
			}
	}
		
	
	public Double getLat() {
		return lat;
	}
	public void setLat(Double late) {
		this.lat = late;
	}
	public Double getLongi() {
		return longi;
	}
	public void setLongi(Double longi) {
		this.longi = longi;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	
	
}
