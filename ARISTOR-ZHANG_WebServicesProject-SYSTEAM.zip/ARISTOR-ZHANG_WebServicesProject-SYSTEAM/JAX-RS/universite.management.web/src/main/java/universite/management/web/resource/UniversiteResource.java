/**
 * 
 */
package universite.management.web.resource;
import java.net.*;

import javax.ws.rs.*;
import javax.ws.rs.core.*;

import universite.management.web.data.*;
import universite.management.web.service.*;
/**
 * @author ARISTOR Christella
 *
 */
@Path("/universites")
public class UniversiteResource {

	UniversiteService service = new UniversiteService();
	@Context
	UriInfo uriInfo;
 
	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public Response addUniversite(Universite u) {
		Universite d = service.addUniversite(u);
		if(d == null) {
			return Response.status(Response.Status.BAD_REQUEST).build();
		}
		URI uri = uriInfo.getRequestUri();
		String newUri = uri.getPath() + "/" + d.getId();
		return Response.status(Response.Status.CREATED).entity(d).contentLocation(uri.resolve(newUri)).build();
	}
	
	@PUT
	@Path("/{id}-{newS}") 
	@Produces(MediaType.APPLICATION_XML)
	public Response updateSpeciality(@PathParam("id") int id, @PathParam("newS")String newS) {
		if (service.updateSpeciality(id, newS) == false) {
			return Response.status(Response.Status.NOT_FOUND).build();
		} else {
			return Response.status(Response.Status.OK).build();
		}
	}
	
	@DELETE
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_XML)
	public Response deleteUniversite(@PathParam("id") int id) { 
		if(service.deleteUniversite(id) == false) {
			return Response.status(Response.Status.NOT_FOUND).build();
		}
		return Response.status(Response.Status.OK).build();
	}
	
	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_XML)
	public Response getUniversite(@PathParam("id") int id) {
		Universite Universite = service.getUniversite(id);
		if(Universite == null) {
			return Response.status(Response.Status.NOT_FOUND).build();
		}
		Link link = Link.fromUri(uriInfo.getRequestUri()).rel("self").type("application/xml").build();
		return Response.status(Response.Status.OK).entity(Universite).links(link).build();
	}
	
	@GET
	@Path("/{speciality}")
	@Produces(MediaType.APPLICATION_XML)
	public Response getUniversite(@PathParam("speciality") String speciality) {
		String uniMap = service.getUniversiteSpeciality(speciality);
		if(uniMap== null) {
			return Response.status(Response.Status.NOT_FOUND).build();
		}
		Link link = Link.fromUri(uriInfo.getRequestUri()).rel("self").type("application/xml").build();
		return Response.status(Response.Status.OK).entity(uniMap).links(link).build();
	}
	
	@GET
	@Path("/")
	@Produces(MediaType.APPLICATION_XML)
	public Response getAllUniversite() {
		String uniMap = service.getAllUniversite();
		if(uniMap== null) {
			return Response.status(Response.Status.NOT_FOUND).build();
		}
		Link link = Link.fromUri(uriInfo.getRequestUri()).rel("self").type("application/xml").build();
		return Response.status(Response.Status.OK).entity(uniMap).links(link).build();
		//GenericEntity<Map<Integer,Universite>> entity = new GenericEntity<Map<Integer,Universite>>(uniMap) {};
	    //return Response.ok(entity).build();
	}

}
